export const WORLD = Object.freeze({ minX: -76, maxX: 76, minZ: -76, maxZ: 64 });
export const CHANNEL_CAPACITY = 108;
export const SPAWN = Object.freeze({ x: 0, z: 20 });
export const BASE_MOVE_SPEED = 4.2;
export const BASE_BOW_DURATION = 4200;

export function bowDropChance(stats = {}) {
  const bonus = Number.isFinite(stats.dropRate) ? Math.max(0, stats.dropRate) : 0;
  return Math.min(0.2, 0.08 + bonus * 0.0012);
}
export const GATHER_REACH = 6.5;
export const RARITIES = Object.freeze({
  common: { label: '일반', color: '#909b88', weight: 54 },
  uncommon: { label: '고급', color: '#5d956d', weight: 29 },
  rare: { label: '희귀', color: '#5f94b0', weight: 12 },
  epic: { label: '영웅', color: '#9a79b3', weight: 4 },
  legendary: { label: '전설', color: '#c69a4e', weight: 1 },
});

const bead = (id, name, rarity, color, description, stats) => ({
  id,
  name,
  type: 'bead',
  rarity,
  color,
  description,
  stats,
});
const cord = (id, name, rarity, color, description, capacity, stats) => ({
  id,
  name,
  type: 'cord',
  rarity,
  color,
  description,
  capacity,
  stats,
});
export const ITEMS = Object.freeze(
  Object.fromEntries(
    [
      bead(
        'pine-bead',
        '소나무 염주알',
        'common',
        '#ba8860',
        '솔향을 은은하게 품은, 수행의 첫 벗입니다.',
        { bowSpeed: 1 },
      ),
      bead(
        'bamboo-bead',
        '대나무 염주알',
        'common',
        '#b1b77a',
        '가볍고 곧은 대나무의 마음을 담았습니다.',
        { moveSpeed: 2 },
      ),
      bead(
        'maple-bead',
        '단풍나무 염주알',
        'common',
        '#b97350',
        '단풍빛 결이 고운 단단한 나무 구슬입니다.',
        { dropRate: 1 },
      ),
      bead(
        'juniper-bead',
        '향나무 염주알',
        'uncommon',
        '#bc8450',
        '절 마당에 머무는 맑은 향을 간직했습니다.',
        { bowSpeed: 3, dropRate: 1 },
      ),
      bead(
        'jujube-bead',
        '대추나무 염주알',
        'uncommon',
        '#9e6249',
        '치밀한 결을 가진 대추나무를 둥글게 다듬었습니다.',
        { dropRate: 3, moveSpeed: 1 },
      ),
      bead(
        'boxwood-bead',
        '회양목 염주알',
        'rare',
        '#d0a95e',
        '천천히 자라 단단해진 나무의 인내가 깃들었습니다.',
        { bowSpeed: 5, moveSpeed: 3 },
      ),
      bead(
        'sandalwood-bead',
        '백단 염주알',
        'rare',
        '#ceb48c',
        '오래도록 잔잔한 향을 내는 귀한 백단입니다.',
        { dropRate: 5, bowSpeed: 3 },
      ),
      bead(
        'rosewood-bead',
        '자단 염주알',
        'epic',
        '#854c48',
        '붉고 치밀한 나뭇결이 세월을 견딥니다.',
        { dropRate: 8, bowSpeed: 5, moveSpeed: 3 },
      ),
      bead(
        'ebony-bead',
        '흑단 염주알',
        'legendary',
        '#45443b',
        '매우 단단하고 희귀한 흑단으로 빚은 깊은 빛의 구슬입니다.',
        { dropRate: 12, bowSpeed: 8, moveSpeed: 5 },
      ),
      bead(
        'agarwood-bead',
        '침향 염주알',
        'legendary',
        '#725349',
        '긴 세월 응축된 향을 품은, 만나기 어려운 귀한 구슬입니다.',
        { dropRate: 15, bowSpeed: 10 },
      ),
      cord(
        'hemp-cord',
        '삼베 염주띠',
        'common',
        '#b49b75',
        '질박한 삼베 실을 꼬아 만든 기본 염주띠입니다.',
        8,
        {},
      ),
      cord(
        'cotton-cord',
        '무명 염주띠',
        'common',
        '#d8cfb7',
        '손목에 부드럽게 감기는 고운 무명 띠입니다.',
        10,
        { bowSpeed: 1 },
      ),
      cord(
        'linen-cord',
        '아마 염주띠',
        'uncommon',
        '#a6a987',
        '질긴 아마 섬유를 촘촘하게 엮었습니다.',
        12,
        { moveSpeed: 3 },
      ),
      cord(
        'silk-cord',
        '명주 염주띠',
        'rare',
        '#90aaa5',
        '여러 겹의 명주실을 꼬아 유연하고 질기게 만들었습니다.',
        18,
        { dropRate: 4, bowSpeed: 3 },
      ),
      cord(
        'braided-silk-cord',
        '오색 금강매듭띠',
        'epic',
        '#ae8b6d',
        '오색 명주실을 단단한 금강매듭으로 엮은 띠입니다.',
        27,
        { dropRate: 6, moveSpeed: 5, bowSpeed: 5 },
      ),
      cord(
        'vajra-cord',
        '백팔 금강염주띠',
        'legendary',
        '#c1a05d',
        '긴 수행을 함께할 수 있도록 명주를 거듭 꼬아 완성했습니다.',
        108,
        { dropRate: 10, moveSpeed: 8, bowSpeed: 8 },
      ),
    ].map((item) => [item.id, item]),
  ),
);

export const THEMES = Object.freeze({
  bamboo: {
    id: 'bamboo',
    name: '청죽의 뜰',
    subtitle: '바람이 쉬어 가는 대숲',
    color: '#718e6a',
    accent: '#d5e4bd',
    loot: [
      'bamboo-bead',
      'pine-bead',
      'juniper-bead',
      'boxwood-bead',
      'rosewood-bead',
      'ebony-bead',
      'hemp-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  lotus: {
    id: 'lotus',
    name: '연화의 못',
    subtitle: '연꽃 위로 번지는 고요',
    color: '#b88a91',
    accent: '#efd4d6',
    loot: [
      'pine-bead',
      'maple-bead',
      'jujube-bead',
      'sandalwood-bead',
      'rosewood-bead',
      'agarwood-bead',
      'cotton-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  pine: {
    id: 'pine',
    name: '솔바람 산사',
    subtitle: '오래된 솔향을 따라서',
    color: '#67836e',
    accent: '#c8dcc7',
    loot: [
      'pine-bead',
      'bamboo-bead',
      'juniper-bead',
      'boxwood-bead',
      'rosewood-bead',
      'ebony-bead',
      'hemp-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  moon: {
    id: 'moon',
    name: '월하의 정원',
    subtitle: '달빛이 머무는 마당',
    color: '#8587ad',
    accent: '#d9daf0',
    loot: [
      'pine-bead',
      'maple-bead',
      'jujube-bead',
      'sandalwood-bead',
      'rosewood-bead',
      'agarwood-bead',
      'cotton-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  dawn: {
    id: 'dawn',
    name: '새벽 종소리',
    subtitle: '하루를 여는 첫 마음',
    color: '#bf986d',
    accent: '#f1dec1',
    loot: [
      'bamboo-bead',
      'maple-bead',
      'juniper-bead',
      'boxwood-bead',
      'rosewood-bead',
      'ebony-bead',
      'hemp-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  snow: {
    id: 'snow',
    name: '설송의 암자',
    subtitle: '눈 위에 남긴 작은 발자국',
    color: '#88a4b1',
    accent: '#e1edf0',
    loot: [
      'pine-bead',
      'bamboo-bead',
      'juniper-bead',
      'sandalwood-bead',
      'rosewood-bead',
      'ebony-bead',
      'cotton-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  autumn: {
    id: 'autumn',
    name: '단풍의 길',
    subtitle: '붉은 잎을 밟는 느린 산책',
    color: '#b67a58',
    accent: '#efd4b7',
    loot: [
      'maple-bead',
      'pine-bead',
      'jujube-bead',
      'boxwood-bead',
      'rosewood-bead',
      'agarwood-bead',
      'hemp-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  mist: {
    id: 'mist',
    name: '운무의 숲',
    subtitle: '안개 너머 들리는 풍경',
    color: '#8a9b91',
    accent: '#dce4da',
    loot: [
      'bamboo-bead',
      'pine-bead',
      'juniper-bead',
      'sandalwood-bead',
      'rosewood-bead',
      'agarwood-bead',
      'cotton-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  mountain: {
    id: 'mountain',
    name: '금강의 능선',
    subtitle: '단단한 마음이 닿는 곳',
    color: '#9b927c',
    accent: '#e4ddca',
    loot: [
      'maple-bead',
      'bamboo-bead',
      'jujube-bead',
      'boxwood-bead',
      'rosewood-bead',
      'ebony-bead',
      'hemp-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
  sacred: {
    id: 'sacred',
    name: '천년 향림',
    subtitle: '오래된 나무가 전하는 이야기',
    color: '#a68b67',
    accent: '#e9d9be',
    loot: [
      'pine-bead',
      'maple-bead',
      'juniper-bead',
      'sandalwood-bead',
      'rosewood-bead',
      'agarwood-bead',
      'cotton-cord',
      'linen-cord',
      'silk-cord',
      'braided-silk-cord',
      'vajra-cord',
    ],
  },
});
export const CHANNELS = Object.freeze(
  Object.values(THEMES).map((theme, index) => ({
    id: `ch-${String(index + 1).padStart(2, '0')}`,
    name: theme.name,
    theme: theme.id,
    number: index + 1,
    capacity: CHANNEL_CAPACITY,
  })),
);
export const HALLS = Object.freeze([
  { id: 'hall-main', name: '대웅전', x: 0, z: -15, radius: 22 },
  { id: 'hall-west', name: '관음전', x: -43, z: -28, radius: 16 },
  { id: 'hall-east', name: '약사전', x: 43, z: -28, radius: 16 },
  { id: 'hall-north', name: '명상전', x: 0, z: -61, radius: 16 },
]);
export const NODES = Object.freeze([
  { id: 'bamboo-west', name: '대숲의 선물', kind: 'bamboo', x: -26, z: 12 },
  { id: 'bamboo-east', name: '대숲의 선물', kind: 'bamboo', x: 30, z: 10 },
  { id: 'pine-west', name: '솔숲의 선물', kind: 'pine', x: -55, z: 22 },
  { id: 'pine-east', name: '솔숲의 선물', kind: 'pine', x: 55, z: 20 },
  { id: 'lotus-west', name: '연못의 선물', kind: 'lotus', x: -24, z: 39 },
  { id: 'lotus-east', name: '연못의 선물', kind: 'lotus', x: 24, z: 39 },
  { id: 'stone-west', name: '돌탑의 선물', kind: 'stone', x: -54, z: -49 },
  { id: 'stone-east', name: '돌탑의 선물', kind: 'stone', x: 55, z: -47 },
  { id: 'cedar-west', name: '향림의 선물', kind: 'cedar', x: -29, z: -60 },
  { id: 'cedar-east', name: '향림의 선물', kind: 'cedar', x: 29, z: -60 },
  { id: 'incense-main', name: '법당 뜰의 선물', kind: 'incense', x: -12, z: -9 },
  { id: 'incense-east', name: '법당 뜰의 선물', kind: 'incense', x: 36, z: -12 },
]);

export function computeStats(inventory = [], equipped = { cord: null, beads: [] }) {
  const byId = new Map(inventory.map((item) => [item.id, ITEMS[item.defId]]));
  const selectedCord = byId.get(equipped.cord);
  const capacity = selectedCord?.type === 'cord' ? selectedCord.capacity : 0;
  const result = { moveSpeed: 0, bowSpeed: 0, dropRate: 0, capacity };
  const selected = [
    selectedCord,
    ...[...new Set(equipped.beads || [])]
      .slice(0, capacity)
      .map((id) => byId.get(id))
      .filter((item) => item?.type === 'bead'),
  ];
  for (const item of selected)
    for (const stat of ['moveSpeed', 'bowSpeed', 'dropRate'])
      result[stat] += item?.stats?.[stat] || 0;
  // Bound server effects even with a complete 108-bead collection.
  result.moveSpeed = Math.min(result.moveSpeed, 75);
  result.bowSpeed = Math.min(result.bowSpeed, 200);
  result.dropRate = Math.min(result.dropRate, 100);
  return result;
}
